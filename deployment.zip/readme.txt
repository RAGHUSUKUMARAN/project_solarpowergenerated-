# Solar Power Prediction App

### Steps to run:

1. Install Python 3.11
2. Install dependencies:
   pip install -r requirements.txt
3. Start the app:
   streamlit run app.py

### Model:
The model used is CatBoost, trained with GridSearchCV on solar generation features.
Model stored as: catboost_model.cbm
