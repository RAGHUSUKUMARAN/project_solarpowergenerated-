# To run this app:
# 1) pip install -r requirements.txt
# 2) streamlit run app.py
# 3) adjust the model path in load_model() as needed
import streamlit as st
import pandas as pd
from catboost import CatBoostRegressor

@st.cache_resource
def load_model():
    model_path = r"D:\DATA-SCIENCE\project\catboost_model.cbm" #adjust the path as needed
    model = CatBoostRegressor()
    model.load_model(model_path)
    return model

model = load_model()

FEATURES = [
    'distance-to-solar-noon',
    'temperature',
    'wind-speed',
    'visibility',
    'humidity',
    'average-wind-speed-(period)',
    'average-pressure-(period)',
    'wind-dir-sin',
    'wind-dir-cos',
    'sky-cover_1',
    'sky-cover_2',
    'sky-cover_3',
    'sky-cover_4'
]

st.title("Solar Power Prediction (CatBoost)")
st.write("Predicting solar energy generation using the trained CatBoost model.")

st.sidebar.header("Input Features")

input_data = {}

for feature in FEATURES:
    input_data[feature] = st.sidebar.number_input(
        label=feature,
        value=0.0,
        format="%.5f"
    )

input_df = pd.DataFrame([input_data])

st.subheader("Input Data")
st.dataframe(input_df)

if st.button("Predict"):
    prediction = model.predict(input_df)[0]
    st.subheader("Prediction Output")
    st.success(f"Estimated Solar Power: {prediction:.2f} W")
